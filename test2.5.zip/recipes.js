/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
module.exports = {
    RECIPE_EN_US: {
        
        'account summary': 'Your credit card balance is $402.32. Your next payment is due on April 15th with a minumum payment of $25. You have $903.28 in your checking account and $3090.22 in your savings account. Looking great!',
        'summary': 'Your credit card balance is $402.32. Your next payment is due on April 15th with a minumum payment of $25. You have $903.28 in your checking account and $3090.22 in your savings account. Looking great!',
        
        'credit card balance': 'Your credit card balance is $402.32',
        'balance': 'Your credit card balance is $402.32',

        'due date': 'Your credit card payment is due on April 15th.',
        'transaction': 'Your last transaction with your Evo card was today at Walmart for $28.99.',
        'purchase': 'Your last transaction with your Evo card was today at Walmart for $28.99.',

        'transfer': 'The transfer will be applied to your account.',
        'send': 'The transfer will be applied to your account.',
        'move': 'The transfer will be applied to your account.'
    }
};
