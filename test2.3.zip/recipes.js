/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
module.exports = {
    RECIPE_EN_US: {
        'snow golem': 'A snow golem can be created by placing a pumpkin on top of  two snow blocks on the ground.',
        'pillar quartz block': 'A pillar of quartz can be obtained by placing a block of quartz on top of a block of quartz in mine craft.',
        'firework rocket': 'A firework rocket can be crafted by placing a firework star in the left middle square, a piece of paper in the center square, and gunpowder in the right middle square in a crafting table. ' +
        'Similar to a firework star, a firework rocket can have more gunpowder added in the bottom row to increase the duration of a rocket.',
        'account summary', 'summary': 'Your credit card balance is $402.32. Your next payment is due on April 15th with a minumum payment of $25. You have $903.28 in your checking account and $3090.22 in your savings account. Looking great!',
        'credit card balance', 'blance', 'account balance': 'Your credit card balance is $402.32',
        'due date': 'Your credit card payment is due on April 15th.',
        'last transaction', 'transaction', 'last purchase', 'recent purchase': 'Your last transaction with your Evo card was today at Walmart for $28.99.'
    }
};
